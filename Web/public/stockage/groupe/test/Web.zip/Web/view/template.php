<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF_8"/>
    <?= $entete ?>
    <title><?= $title ?></title>
</head>

<?= $style ?>

<script>
    <?= $script ?>
</script>

<body>
    <?= $content ?>
</body>

</html>