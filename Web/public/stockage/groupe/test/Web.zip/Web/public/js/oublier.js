$(document).ready(function(){
		$("#myModal").modal('show');
	});